#include "queue.h"

queue::queue() {
	
} // constructor
