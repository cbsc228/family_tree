//------------------------------------------
//              class queue
//------------------------------------------
// Describes a queue used for BFS
//------------------------------------------
using namespace std;

class queue {
public:
	//default constructor
	queue(); 
	//inserts a new node
	void push();
	//removes a node from front of queue
	void pop();
private:

};